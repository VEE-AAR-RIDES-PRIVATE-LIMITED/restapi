import email
from unicodedata import name
from django.db import models
from django.forms import CharField


# Create your models here.


GENDER_ALL=((
    ('Male','Male'),
    ('Female','Female'),
    ('Other','Other'),
))
class Student(models.Model):
    name = models.CharField(max_length=355)
    species = models.CharField(max_length=200)
    breed = models.CharField(max_length=299)
    image = models.ImageField(upload_to='category/')
    gender = models.CharField(max_length=40 , choices=GENDER_ALL)
    # date = models.DateTimeField(auto_now_add=True)
    date = models.DateField(null=True, blank=True, default='')
    

